import tkinter as tk
from tkinter import ttk, messagebox
import math
from calculator_logic import CalculatorLogic
from theme_manager import ThemeManager
from history_manager import HistoryManager

class SmartCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Calculator")
        self.root.geometry("800x550")
        self.root.resizable(True, True)
        self.root.minsize(800, 550)
        
        # Initialize managers
        self.theme_manager = ThemeManager(self.root)
        self.history_manager = HistoryManager()
        self.calculator_logic = CalculatorLogic()
        
        # Main frame to hold everything
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create frames for different sections
        self.setup_frames()
        
        # Create calculator display
        self.setup_display()
        
        # Create calculator buttons
        self.setup_buttons()
        
        # Create history section
        self.setup_history()
        
        # Apply theme
        self.theme_manager.apply_theme()

    def setup_frames(self):
        # Left frame for calculator
        self.calculator_frame = tk.Frame(self.main_frame)
        self.calculator_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Right frame for history
        self.history_frame = tk.Frame(self.main_frame)
        self.history_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        # Calculator display frame
        self.display_frame = tk.Frame(self.calculator_frame)
        self.display_frame.pack(side=tk.TOP, fill=tk.X, pady=(0, 10))
        
        # Calculator buttons frame
        self.buttons_frame = tk.Frame(self.calculator_frame)
        self.buttons_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        # Scientific buttons frame
        self.scientific_frame = tk.Frame(self.buttons_frame)
        self.scientific_frame.pack(side=tk.TOP, fill=tk.X, pady=(0, 10))
        
        # Standard buttons frame
        self.standard_frame = tk.Frame(self.buttons_frame)
        self.standard_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    def setup_display(self):
        # Expression display (shows the current expression)
        self.expression_var = tk.StringVar()
        self.expression_var.set("")
        self.expression_display = tk.Entry(
            self.display_frame, 
            textvariable=self.expression_var, 
            font=("Arial", 14), 
            bd=10, 
            insertwidth=4, 
            justify='right'
        )
        self.expression_display.pack(fill=tk.X, pady=(10, 0))
        
        # Result display (shows the result of the calculation)
        self.result_var = tk.StringVar()
        self.result_var.set("0")
        self.result_display = tk.Label(
            self.display_frame, 
            textvariable=self.result_var, 
            font=("Arial", 24, "bold"), 
            bd=5, 
            relief=tk.SUNKEN, 
            anchor='e',
            padx=10, 
            pady=10
        )
        self.result_display.pack(fill=tk.X, pady=(5, 0))
        
        # Theme toggle button
        self.theme_button = tk.Button(
            self.display_frame, 
            text="Toggle Theme", 
            command=self.toggle_theme, 
            font=("Arial", 10),
            padx=10,
            pady=5
        )
        self.theme_button.pack(side=tk.TOP, anchor='e', pady=(5, 0))

    def setup_buttons(self):
        # Scientific buttons
        scientific_buttons = [
            ('sin', lambda: self.append_function('sin(')),
            ('cos', lambda: self.append_function('cos(')),
            ('tan', lambda: self.append_function('tan(')),
            ('log', lambda: self.append_function('log(')),
            ('ln', lambda: self.append_function('ln(')),
            ('√', lambda: self.append_function('sqrt(')),
            ('π', lambda: self.append_text('pi')),
            ('e', lambda: self.append_text('e')),
            ('|x|', lambda: self.append_function('abs(')),
            ('x²', lambda: self.append_text('^2')),
            ('x³', lambda: self.append_text('^3')),
            ('xʸ', lambda: self.append_text('^')),
            ('(', lambda: self.append_text('(')),
            (')', lambda: self.append_text(')')),
        ]
        
        row, col = 0, 0
        for (text, command) in scientific_buttons:
            btn = tk.Button(
                self.scientific_frame, 
                text=text, 
                command=command, 
                font=("Arial", 12),
                padx=10, 
                pady=10, 
                width=5
            )
            btn.grid(row=row, column=col, padx=2, pady=2, sticky='nsew')
            col += 1
            if col > 6:  # 7 buttons per row
                col = 0
                row += 1
        
        # Configure grid for scientific_frame
        for i in range(7):
            self.scientific_frame.grid_columnconfigure(i, weight=1)
        
        # Standard calculator buttons
        standard_buttons = [
            ('7', lambda: self.append_text('7')),
            ('8', lambda: self.append_text('8')),
            ('9', lambda: self.append_text('9')),
            ('DEL', self.delete_last),
            ('AC', self.clear_all),
            
            ('4', lambda: self.append_text('4')),
            ('5', lambda: self.append_text('5')),
            ('6', lambda: self.append_text('6')),
            ('×', lambda: self.append_text('*')),
            ('÷', lambda: self.append_text('/')),
            
            ('1', lambda: self.append_text('1')),
            ('2', lambda: self.append_text('2')),
            ('3', lambda: self.append_text('3')),
            ('+', lambda: self.append_text('+')),
            ('-', lambda: self.append_text('-')),
            
            ('0', lambda: self.append_text('0')),
            ('.', lambda: self.append_text('.')),
            ('±', self.negate),
            ('ANS', self.use_last_answer),
            ('=', self.calculate),
        ]
        
        row, col = 0, 0
        for (text, command) in standard_buttons:
            btn = tk.Button(
                self.standard_frame, 
                text=text, 
                command=command, 
                font=("Arial", 16, "bold"),
                padx=15, 
                pady=15, 
                width=5
            )
            btn.grid(row=row, column=col, padx=2, pady=2, sticky='nsew')
            col += 1
            if col > 4:  # 5 buttons per row
                col = 0
                row += 1
        
        # Special styling for some buttons
        for widget in self.standard_frame.winfo_children():
            if widget['text'] == '=':
                widget.configure(bg='#4CAF50', fg='white')
            elif widget['text'] in ('AC', 'DEL'):
                widget.configure(bg='#F44336', fg='white')
            elif widget['text'] in ('+', '-', '×', '÷'):
                widget.configure(bg='#2196F3', fg='white')
        
        # Configure grid for standard_frame
        for i in range(5):
            self.standard_frame.grid_columnconfigure(i, weight=1)
        for i in range(4):
            self.standard_frame.grid_rowconfigure(i, weight=1)

    def setup_history(self):
        # History heading
        history_label = tk.Label(
            self.history_frame, 
            text="Calculation History", 
            font=("Arial", 14, "bold"),
            pady=10
        )
        history_label.pack(side=tk.TOP, fill=tk.X)
        
        # Clear history button
        clear_history_btn = tk.Button(
            self.history_frame, 
            text="Clear History", 
            command=self.clear_history,
            font=("Arial", 10),
            padx=5,
            pady=2
        )
        clear_history_btn.pack(side=tk.TOP, anchor='e', pady=(0, 5))
        
        # History listbox with scrollbar
        history_frame = tk.Frame(self.history_frame)
        history_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(history_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.history_listbox = tk.Listbox(
            history_frame, 
            font=("Arial", 12),
            selectbackground="#a6a6a6",
            yscrollcommand=scrollbar.set
        )
        self.history_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar.config(command=self.history_listbox.yview)
        
        # Bind double-click event to use history item
        self.history_listbox.bind('<Double-1>', self.use_history_item)

    def append_text(self, text):
        current = self.expression_var.get()
        self.expression_var.set(current + text)

    def append_function(self, function):
        current = self.expression_var.get()
        self.expression_var.set(current + function)

    def delete_last(self):
        current = self.expression_var.get()
        self.expression_var.set(current[:-1])

    def clear_all(self):
        self.expression_var.set("")
        self.result_var.set("0")

    def negate(self):
        current = self.expression_var.get()
        if current and current[0] == '-':
            self.expression_var.set(current[1:])
        else:
            self.expression_var.set('-' + current)

    def use_last_answer(self):
        last_result = self.calculator_logic.get_last_answer()
        if last_result is not None:
            self.append_text(str(last_result))

    def calculate(self):
        expression = self.expression_var.get()
        if not expression:
            return
        
        try:
            result = self.calculator_logic.evaluate(expression)
            self.result_var.set(result)
            
            # Add to history
            history_entry = f"{expression} = {result}"
            self.history_manager.add_entry(history_entry)
            self.update_history_display()
            
        except Exception as e:
            self.result_var.set("Error")
            messagebox.showerror("Calculation Error", str(e))

    def clear_history(self):
        self.history_manager.clear()
        self.update_history_display()

    def update_history_display(self):
        # Clear current listbox
        self.history_listbox.delete(0, tk.END)
        
        # Add all history items
        for item in self.history_manager.get_entries():
            self.history_listbox.insert(tk.END, item)

    def use_history_item(self, event):
        # Get selected item index
        selected_index = self.history_listbox.curselection()
        if not selected_index:
            return
        
        # Get the selected item
        selected_item = self.history_listbox.get(selected_index[0])
        
        # Extract the expression part (before '=')
        if '=' in selected_item:
            expression = selected_item.split('=')[0].strip()
            self.expression_var.set(expression)

    def toggle_theme(self):
        self.theme_manager.toggle_theme()
        self.update_button_colors()

    def update_button_colors(self):
        # Update colors based on current theme
        is_dark = self.theme_manager.is_dark_mode()
        
        # Update special button colors
        for widget in self.standard_frame.winfo_children():
            if widget['text'] == '=':
                widget.configure(bg='#4CAF50' if not is_dark else '#2E7D32', fg='white')
            elif widget['text'] in ('AC', 'DEL'):
                widget.configure(bg='#F44336' if not is_dark else '#C62828', fg='white')
            elif widget['text'] in ('+', '-', '×', '÷'):
                widget.configure(bg='#2196F3' if not is_dark else '#1565C0', fg='white')

if __name__ == "__main__":
    root = tk.Tk()
    app = SmartCalculator(root)
    root.mainloop()
