import math
import re

class CalculatorLogic:
    """
    Class to handle calculator operations and maintain calculation history.
    """
    def __init__(self):
        self.history = []
        self.last_answer = None
    
    def add_to_history(self, calculation):
        """Add a calculation to the history."""
        self.history.append(calculation)
        # Keep history limited to last 100 calculations
        if len(self.history) > 100:
            self.history.pop(0)
    
    def get_last_answer(self):
        """Return the last calculated answer."""
        return self.last_answer
    
    def evaluate(self, expression):
        """
        Evaluate a mathematical expression.
        Handles basic arithmetic as well as scientific functions.
        """
        # First, handle the custom functions and constants
        processed_expr = self._preprocess_expression(expression)
        
        try:
            # Use Python's built-in eval for basic arithmetic
            # This is safe for our limited mathematical context
            result = eval(processed_expr)
            
            # Store the result as the last answer
            self.last_answer = result
            
            # Format the result
            if isinstance(result, (int, float)):
                # If it's an integer, display it as an integer
                if result == int(result):
                    return str(int(result))
                    
                # Otherwise format it to a reasonable number of decimal places
                # Avoid scientific notation for reasonable numbers
                if abs(result) < 1e10:
                    return f"{result:.10g}"
                else:
                    return f"{result:.10e}"
            
            return str(result)
        
        except Exception as e:
            # Handle specific errors
            if "division by zero" in str(e):
                raise ValueError("Division by zero is not allowed")
            elif "invalid syntax" in str(e):
                raise ValueError("Invalid expression syntax")
            else:
                raise ValueError(f"Error calculating result: {str(e)}")
    
    def _preprocess_expression(self, expression):
        """
        Preprocess the expression to handle scientific functions.
        """
        # Replace custom syntax with Python equivalents
        processed = expression
        
        # Replace scientific notations
        processed = processed.replace("sin(", "math.sin(")
        processed = processed.replace("cos(", "math.cos(")
        processed = processed.replace("tan(", "math.tan(")
        processed = processed.replace("sqrt(", "math.sqrt(")
        processed = processed.replace("log(", "math.log10(")
        processed = processed.replace("ln(", "math.log(")
        
        # Handle powers: x^n notation
        processed = re.sub(r'\(([^)]+)\)\^2', r'math.pow(\1, 2)', processed)
        processed = re.sub(r'\(([^)]+)\)\^3', r'math.pow(\1, 3)', processed)
        
        # Safety check for valid python expression
        # Restrict to math operations only
        safe_chars = set("0123456789.+-*/()^ ")
        safe_funcs = ["math.sin", "math.cos", "math.tan", "math.sqrt", 
                     "math.log10", "math.log", "math.pow", "math.pi", "math.e"]
        
        # Remove all whitespace for checking
        clean_expr = processed.replace(" ", "")
        
        # Check if the expression contains only safe characters and functions
        for func in safe_funcs:
            clean_expr = clean_expr.replace(func, "")
        
        if not all(c in safe_chars for c in clean_expr):
            raise ValueError("Expression contains invalid characters or functions")
        
        return processed
