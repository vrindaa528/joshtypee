import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import sqlite3
import os
import re
from datetime import datetime

class StudentManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Management System")
        self.root.geometry("1200x700")
        self.root.resizable(True, True)
        self.root.minsize(1000, 600)
        
        # Database setup
        self.db_name = "student_management.db"
        self.check_database()
        
        # Set theme colors
        self.bg_color = "#f5f5f5"
        self.accent_color = "#3498db"
        self.text_color = "#333333"
        self.success_color = "#2ecc71"
        self.warning_color = "#e74c3c"
        
        # Set up the styles
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("TFrame", background=self.bg_color)
        self.style.configure("TLabel", background=self.bg_color, foreground=self.text_color)
        self.style.configure("TEntry", fieldbackground="white")
        self.style.configure("Accent.TButton", background=self.accent_color, foreground="white")
        self.style.map("Accent.TButton", background=[("active", "#2980b9")])
        
        # Tab control
        self.tab_control = ttk.Notebook(self.root)
        self.tab_control.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create tabs
        self.students_tab = ttk.Frame(self.tab_control)
        self.courses_tab = ttk.Frame(self.tab_control)
        self.enrollments_tab = ttk.Frame(self.tab_control)
        self.reports_tab = ttk.Frame(self.tab_control)
        
        self.tab_control.add(self.students_tab, text="Students")
        self.tab_control.add(self.courses_tab, text="Courses")
        self.tab_control.add(self.enrollments_tab, text="Enrollments")
        self.tab_control.add(self.reports_tab, text="Reports")
        
        # Initialize student management
        self.setup_student_management()
        
        # Initialize course management
        self.setup_course_placeholder()
        
        # Initialize enrollment management
        self.setup_enrollment_placeholder()
        
        # Initialize reports
        self.setup_reports_placeholder()
    
    def check_database(self):
        """Check if database exists, if not suggest creating it"""
        if not os.path.exists(self.db_name):
            result = messagebox.askyesno(
                "Database Not Found", 
                "The student database was not found. Would you like to create it now?\n\n"
                "This will create the database schema based on student_db_schema.sql"
            )
            if result:
                try:
                    self.create_database()
                except Exception as e:
                    messagebox.showerror("Database Error", f"Failed to create database: {e}")
    
    def create_database(self):
        """Create the database from the schema file"""
        import setup_database
        setup_database.setup_database()
    
    def setup_student_management(self):
        """Set up the student management tab"""
        # Variables for form inputs
        self.student_id_var = tk.StringVar()
        self.student_number_var = tk.StringVar()
        self.first_name_var = tk.StringVar()
        self.last_name_var = tk.StringVar()
        self.email_var = tk.StringVar()
        self.phone_var = tk.StringVar()
        self.dob_var = tk.StringVar()
        self.gender_var = tk.StringVar()
        self.department_id_var = tk.IntVar()
        self.status_var = tk.StringVar()
        self.search_var = tk.StringVar()
        
        # Set up the UI components for students tab
        self.setup_student_main_frames()
        self.setup_student_form()
        self.setup_student_table()
        self.setup_student_search()
        
        # Populate the table
        self.display_all_students()
        
        # Set up validation
        self.setup_student_validation()
    
    def setup_student_main_frames(self):
        # Main container for the app
        self.student_main_frame = ttk.Frame(self.students_tab, padding=10)
        self.student_main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title label
        title_label = ttk.Label(self.student_main_frame, text="Student Management", 
                              font=("Arial", 18, "bold"))
        title_label.pack(pady=(0, 15))
        
        # Split into left and right frames
        self.student_content_frame = ttk.Frame(self.student_main_frame)
        self.student_content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Left frame for form
        self.student_form_frame = ttk.LabelFrame(self.student_content_frame, text="Student Information", padding=15)
        self.student_form_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10), pady=5)
        
        # Right frame for the table
        self.student_table_frame = ttk.LabelFrame(self.student_content_frame, text="Student List", padding=15)
        self.student_table_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0), pady=5)
    
    def setup_student_form(self):
        # Create a frame for the form fields
        form_fields_frame = ttk.Frame(self.student_form_frame)
        form_fields_frame.pack(fill=tk.BOTH, expand=True)
        
        # Student ID (hidden)
        self.student_id_var.set("")
        
        # Student Number
        ttk.Label(form_fields_frame, text="Student Number:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.student_number_var, width=30).grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        ttk.Label(form_fields_frame, text="(Auto-generated if empty)").grid(row=0, column=2, sticky="w", padx=5, pady=5)
        
        # First Name
        ttk.Label(form_fields_frame, text="First Name:*").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.first_name_var, width=30).grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        self.first_name_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.first_name_error.grid(row=1, column=2, sticky="w", padx=5, pady=5)
        
        # Last Name
        ttk.Label(form_fields_frame, text="Last Name:*").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.last_name_var, width=30).grid(row=2, column=1, sticky="ew", padx=5, pady=5)
        self.last_name_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.last_name_error.grid(row=2, column=2, sticky="w", padx=5, pady=5)
        
        # Email
        ttk.Label(form_fields_frame, text="Email:*").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.email_var, width=30).grid(row=3, column=1, sticky="ew", padx=5, pady=5)
        self.email_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.email_error.grid(row=3, column=2, sticky="w", padx=5, pady=5)
        
        # Phone
        ttk.Label(form_fields_frame, text="Phone:").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.phone_var, width=30).grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        self.phone_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.phone_error.grid(row=4, column=2, sticky="w", padx=5, pady=5)
        
        # Date of Birth
        ttk.Label(form_fields_frame, text="Date of Birth:").grid(row=5, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.dob_var, width=30).grid(row=5, column=1, sticky="ew", padx=5, pady=5)
        ttk.Label(form_fields_frame, text="(YYYY-MM-DD)").grid(row=5, column=2, sticky="w", padx=5, pady=5)
        
        # Gender
        ttk.Label(form_fields_frame, text="Gender:").grid(row=6, column=0, sticky="w", padx=5, pady=5)
        gender_frame = ttk.Frame(form_fields_frame)
        gender_frame.grid(row=6, column=1, sticky="ew", padx=5, pady=5)
        
        genders = ["Male", "Female", "Other", "Prefer not to say"]
        gender_combo = ttk.Combobox(gender_frame, textvariable=self.gender_var, values=genders, width=27)
        gender_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Department
        ttk.Label(form_fields_frame, text="Department:*").grid(row=7, column=0, sticky="w", padx=5, pady=5)
        
        # Get departments from the database
        departments = self.get_departments()
        self.department_combo = ttk.Combobox(form_fields_frame, width=30)
        self.department_combo.grid(row=7, column=1, sticky="ew", padx=5, pady=5)
        
        # Set up departments in the combobox
        self.department_names = []
        self.department_ids = []
        
        if departments:
            for dept in departments:
                self.department_ids.append(dept[0])
                self.department_names.append(f"{dept[1]} ({dept[2]})")
            
            self.department_combo['values'] = self.department_names
        
        # Bind department selection event
        self.department_combo.bind("<<ComboboxSelected>>", self.on_department_selected)
        
        # Status
        ttk.Label(form_fields_frame, text="Status:").grid(row=8, column=0, sticky="w", padx=5, pady=5)
        statuses = ["Active", "Graduated", "On Leave", "Withdrawn"]
        status_combo = ttk.Combobox(form_fields_frame, textvariable=self.status_var, values=statuses, width=27)
        status_combo.grid(row=8, column=1, sticky="ew", padx=5, pady=5)
        
        # Default to Active
        status_combo.set("Active")
        
        # Additional notes
        ttk.Label(form_fields_frame, text="Notes:").grid(row=9, column=0, sticky="nw", padx=5, pady=5)
        self.notes_text = scrolledtext.ScrolledText(form_fields_frame, width=30, height=4)
        self.notes_text.grid(row=9, column=1, columnspan=2, sticky="ew", padx=5, pady=5)
        
        # Required fields note
        required_note = ttk.Label(form_fields_frame, text="* Required fields", foreground=self.warning_color)
        required_note.grid(row=10, column=0, columnspan=3, sticky="w", padx=5, pady=5)
        
        # Create a frame for buttons
        button_frame = ttk.Frame(self.student_form_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Add buttons for CRUD operations
        ttk.Button(button_frame, text="Add Student", command=self.add_student, style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Update Selected", command=self.update_student).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete Selected", command=self.delete_student).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear Form", command=self.clear_student_form).pack(side=tk.LEFT, padx=5)
    
    def get_departments(self):
        """Get list of departments from database"""
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            cursor.execute("SELECT id, name, code FROM departments ORDER BY name")
            departments = cursor.fetchall()
            conn.close()
            return departments
        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching departments: {e}")
            return []
    
    def on_department_selected(self, event):
        """Handle department selection"""
        if self.department_combo.current() >= 0:
            selected_index = self.department_combo.current()
            self.department_id_var.set(self.department_ids[selected_index])
    
    def setup_student_table(self):
        # Create frame for search and buttons above table
        table_top_frame = ttk.Frame(self.student_table_frame)
        table_top_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Create the Treeview widget
        columns = ("id", "student_number", "name", "email", "department", "status")
        self.student_tree = ttk.Treeview(self.student_table_frame, columns=columns, show="headings", selectmode="browse")
        
        # Define column headings
        self.student_tree.heading("id", text="ID")
        self.student_tree.heading("student_number", text="Student #")
        self.student_tree.heading("name", text="Name")
        self.student_tree.heading("email", text="Email")
        self.student_tree.heading("department", text="Department")
        self.student_tree.heading("status", text="Status")
        
        # Define column widths
        self.student_tree.column("id", width=50, anchor="center")
        self.student_tree.column("student_number", width=100, anchor="center")
        self.student_tree.column("name", width=180, anchor="w")
        self.student_tree.column("email", width=180, anchor="w")
        self.student_tree.column("department", width=150, anchor="w")
        self.student_tree.column("status", width=80, anchor="center")
        
        # Bind the select event
        self.student_tree.bind("<<TreeviewSelect>>", self.load_selected_student)
        
        # Add a scrollbar
        scrollbar = ttk.Scrollbar(self.student_table_frame, orient="vertical", command=self.student_tree.yview)
        self.student_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack the Treeview and scrollbar
        self.student_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def setup_student_search(self):
        # Create search frame
        search_frame = ttk.Frame(self.student_main_frame)
        search_frame.pack(fill=tk.X, pady=(10, 0))
        
        # Search field
        ttk.Label(search_frame, text="Search Students:").pack(side=tk.LEFT, padx=(0, 5))
        ttk.Entry(search_frame, textvariable=self.search_var, width=40).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(search_frame, text="Search", command=self.search_students).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(search_frame, text="Clear Search", command=self.display_all_students).pack(side=tk.LEFT, padx=(0, 5))
    
    def setup_student_validation(self):
        # Set up validation for form fields
        
        # Track changes to form fields for real-time validation
        self.first_name_var.trace_add("write", lambda *args: self.validate_name(self.first_name_var, self.first_name_error, "First name"))
        self.last_name_var.trace_add("write", lambda *args: self.validate_name(self.last_name_var, self.last_name_error, "Last name"))
        self.email_var.trace_add("write", lambda *args: self.validate_email())
        self.phone_var.trace_add("write", lambda *args: self.validate_phone())
    
    def validate_name(self, var, error_label, field_name):
        name = var.get().strip()
        if name:
            if not name.replace(' ', '').isalpha():
                error_label.config(text=f"{field_name} should contain only letters")
                return False
            else:
                error_label.config(text="")
                return True
        else:
            error_label.config(text=f"{field_name} is required")
            return False
    
    def validate_email(self):
        email = self.email_var.get().strip()
        if email:
            # Simple email validation
            if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                self.email_error.config(text="Invalid email format")
                return False
            else:
                self.email_error.config(text="")
                return True
        else:
            self.email_error.config(text="Email is required")
            return False
    
    def validate_phone(self):
        phone = self.phone_var.get().strip()
        if phone:
            # Simple phone validation
            if not re.match(r"^[\d\s\(\)\-\+]+$", phone):
                self.phone_error.config(text="Invalid phone format")
                return False
            else:
                self.phone_error.config(text="")
                return True
        else:
            # Phone is optional
            self.phone_error.config(text="")
            return True
    
    def validate_student_form(self):
        # Validate all form fields
        valid_first_name = self.validate_name(self.first_name_var, self.first_name_error, "First name")
        valid_last_name = self.validate_name(self.last_name_var, self.last_name_error, "Last name")
        valid_email = self.validate_email()
        valid_phone = self.validate_phone()
        
        # Check if department is selected
        if self.department_id_var.get() <= 0:
            messagebox.showerror("Validation Error", "Department is required")
            return False
        
        # Check date of birth if provided
        dob = self.dob_var.get().strip()
        if dob:
            try:
                datetime.strptime(dob, '%Y-%m-%d')
            except ValueError:
                messagebox.showerror("Validation Error", "Date of birth must be in YYYY-MM-DD format")
                return False
        
        # Return overall validation result
        return valid_first_name and valid_last_name and valid_email and valid_phone
    
    def add_student(self):
        """Add a new student to the database"""
        # Validate form
        if not self.validate_student_form():
            return
        
        # Get data from form
        student_number = self.student_number_var.get().strip()
        first_name = self.first_name_var.get().strip()
        last_name = self.last_name_var.get().strip()
        email = self.email_var.get().strip()
        phone = self.phone_var.get().strip()
        dob = self.dob_var.get().strip()
        gender = self.gender_var.get().strip()
        department_id = self.department_id_var.get()
        status = self.status_var.get().strip()
        notes = self.notes_text.get("1.0", tk.END).strip()
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Generate student number if not provided
            if not student_number:
                # Generate a student number based on current year and a unique identifier
                current_year = datetime.now().year
                
                # Get the highest student number starting with the current year
                cursor.execute(
                    "SELECT student_number FROM students WHERE student_number LIKE ? ORDER BY student_number DESC LIMIT 1", 
                    (f"{current_year}%",)
                )
                result = cursor.fetchone()
                
                if result and result[0]:
                    last_number = result[0]
                    # If the last number is in format YYYYNNN, increment the NNN part
                    sequence = int(last_number[4:]) + 1
                else:
                    # Start with 001
                    sequence = 1
                
                # Format: YYYY followed by 3-digit sequence
                student_number = f"{current_year}{sequence:03d}"
            
            # Check if the email already exists
            cursor.execute("SELECT id FROM students WHERE email = ?", (email,))
            if cursor.fetchone():
                messagebox.showerror("Error", "A student with this email already exists")
                conn.close()
                return
            
            # Check if the student number already exists
            if student_number:
                cursor.execute("SELECT id FROM students WHERE student_number = ?", (student_number,))
                if cursor.fetchone():
                    messagebox.showerror("Error", "A student with this student number already exists")
                    conn.close()
                    return
            
            # Insert the new student
            cursor.execute('''
                INSERT INTO students (
                    student_number, first_name, last_name, email, phone, date_of_birth, 
                    gender, department_id, status, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                student_number, first_name, last_name, email, phone, dob,
                gender, department_id, status, notes
            ))
            
            conn.commit()
            messagebox.showinfo("Success", f"Student {first_name} {last_name} added successfully")
            
            # Refresh the table and clear the form
            self.clear_student_form()
            self.display_all_students()
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def update_student(self):
        """Update the selected student in the database"""
        # Check if a student is selected
        selected_items = self.student_tree.selection()
        if not selected_items:
            messagebox.showinfo("Info", "Please select a student to update")
            return
        
        # Validate form
        if not self.validate_student_form():
            return
        
        # Get student ID from the selected item
        student_id = self.student_id_var.get()
        
        # Get data from form
        student_number = self.student_number_var.get().strip()
        first_name = self.first_name_var.get().strip()
        last_name = self.last_name_var.get().strip()
        email = self.email_var.get().strip()
        phone = self.phone_var.get().strip()
        dob = self.dob_var.get().strip()
        gender = self.gender_var.get().strip()
        department_id = self.department_id_var.get()
        status = self.status_var.get().strip()
        notes = self.notes_text.get("1.0", tk.END).strip()
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Check if the email already exists for a different student
            cursor.execute("SELECT id FROM students WHERE email = ? AND id != ?", (email, student_id))
            if cursor.fetchone():
                messagebox.showerror("Error", "Another student with this email already exists")
                conn.close()
                return
            
            # Check if the student number already exists for a different student
            if student_number:
                cursor.execute("SELECT id FROM students WHERE student_number = ? AND id != ?", (student_number, student_id))
                if cursor.fetchone():
                    messagebox.showerror("Error", "Another student with this student number already exists")
                    conn.close()
                    return
            
            # Update the student
            cursor.execute('''
                UPDATE students SET
                    student_number = ?, first_name = ?, last_name = ?, email = ?, phone = ?, 
                    date_of_birth = ?, gender = ?, department_id = ?, status = ?, notes = ?
                WHERE id = ?
            ''', (
                student_number, first_name, last_name, email, phone, 
                dob, gender, department_id, status, notes, student_id
            ))
            
            conn.commit()
            messagebox.showinfo("Success", f"Student {first_name} {last_name} updated successfully")
            
            # Refresh the table and clear the form
            self.clear_student_form()
            self.display_all_students()
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def delete_student(self):
        """Delete the selected student from the database"""
        # Check if a student is selected
        selected_items = self.student_tree.selection()
        if not selected_items:
            messagebox.showinfo("Info", "Please select a student to delete")
            return
        
        # Get student ID and name from the selected item
        student_id = self.student_id_var.get()
        student_name = f"{self.first_name_var.get()} {self.last_name_var.get()}"
        
        # Confirm deletion
        if not messagebox.askyesno("Confirm", f"Are you sure you want to delete {student_name}?"):
            return
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Delete the student
            cursor.execute("DELETE FROM students WHERE id = ?", (student_id,))
            
            conn.commit()
            messagebox.showinfo("Success", f"Student {student_name} deleted successfully")
            
            # Refresh the table and clear the form
            self.clear_student_form()
            self.display_all_students()
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def load_selected_student(self, event):
        """Load the selected student's data into the form"""
        # Get selected student
        selected_items = self.student_tree.selection()
        if not selected_items:
            return
        
        # Get student ID from the selected item
        student_id = self.student_tree.item(selected_items[0], "values")[0]
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Get student data
            cursor.execute('''
                SELECT s.id, s.student_number, s.first_name, s.last_name, s.email, s.phone, 
                       s.date_of_birth, s.gender, s.department_id, d.name, d.code, s.status, s.notes
                FROM students s
                LEFT JOIN departments d ON s.department_id = d.id
                WHERE s.id = ?
            ''', (student_id,))
            
            student = cursor.fetchone()
            if student:
                # Clear error messages
                self.first_name_error.config(text="")
                self.last_name_error.config(text="")
                self.email_error.config(text="")
                self.phone_error.config(text="")
                
                # Populate form with student data
                self.student_id_var.set(student[0])
                self.student_number_var.set(student[1] if student[1] else "")
                self.first_name_var.set(student[2])
                self.last_name_var.set(student[3])
                self.email_var.set(student[4])
                self.phone_var.set(student[5] if student[5] else "")
                self.dob_var.set(student[6] if student[6] else "")
                self.gender_var.set(student[7] if student[7] else "")
                
                # Set department
                department_id = student[8]
                self.department_id_var.set(department_id if department_id else 0)
                
                if department_id and student[9] and student[10]:
                    # Find the department in the combobox
                    dept_name = f"{student[9]} ({student[10]})"
                    if dept_name in self.department_names:
                        self.department_combo.set(dept_name)
                else:
                    self.department_combo.set("")
                
                # Set status
                self.status_var.set(student[11] if student[11] else "Active")
                
                # Set notes
                self.notes_text.delete("1.0", tk.END)
                if student[12]:
                    self.notes_text.insert("1.0", student[12])
        
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def clear_student_form(self):
        """Clear the student form"""
        self.student_id_var.set("")
        self.student_number_var.set("")
        self.first_name_var.set("")
        self.last_name_var.set("")
        self.email_var.set("")
        self.phone_var.set("")
        self.dob_var.set("")
        self.gender_var.set("")
        self.department_id_var.set(0)
        self.department_combo.set("")
        self.status_var.set("Active")
        self.notes_text.delete("1.0", tk.END)
        
        # Clear error messages
        self.first_name_error.config(text="")
        self.last_name_error.config(text="")
        self.email_error.config(text="")
        self.phone_error.config(text="")
        
        # Deselect tree item
        for selected_item in self.student_tree.selection():
            self.student_tree.selection_remove(selected_item)
    
    def display_all_students(self):
        """Display all students in the tree view"""
        # Clear search field
        self.search_var.set("")
        
        # Clear the tree
        for item in self.student_tree.get_children():
            self.student_tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Get all students with department names
            cursor.execute('''
                SELECT s.id, s.student_number, s.first_name, s.last_name, s.email, 
                       d.name AS department_name, s.status
                FROM students s
                LEFT JOIN departments d ON s.department_id = d.id
                ORDER BY s.last_name, s.first_name
            ''')
            
            for student in cursor.fetchall():
                # Format the student name
                full_name = f"{student[2]} {student[3]}"
                
                # Insert into the tree
                self.student_tree.insert("", tk.END, values=(
                    student[0],
                    student[1] if student[1] else "",
                    full_name,
                    student[4],
                    student[5] if student[5] else "",
                    student[6] if student[6] else "Active"
                ))
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def search_students(self):
        """Search for students based on the search text"""
        search_text = self.search_var.get().strip()
        if not search_text:
            self.display_all_students()
            return
        
        # Clear the tree
        for item in self.student_tree.get_children():
            self.student_tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Search in multiple fields
            cursor.execute('''
                SELECT s.id, s.student_number, s.first_name, s.last_name, s.email, 
                       d.name AS department_name, s.status
                FROM students s
                LEFT JOIN departments d ON s.department_id = d.id
                WHERE s.student_number LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? 
                      OR s.email LIKE ? OR d.name LIKE ?
                ORDER BY s.last_name, s.first_name
            ''', (f"%{search_text}%", f"%{search_text}%", f"%{search_text}%", f"%{search_text}%", f"%{search_text}%"))
            
            students = cursor.fetchall()
            for student in students:
                # Format the student name
                full_name = f"{student[2]} {student[3]}"
                
                # Insert into the tree
                self.student_tree.insert("", tk.END, values=(
                    student[0],
                    student[1] if student[1] else "",
                    full_name,
                    student[4],
                    student[5] if student[5] else "",
                    student[6] if student[6] else "Active"
                ))
            
            # Show search results count
            if not students:
                messagebox.showinfo("Search Results", "No students match your search criteria")
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def setup_course_placeholder(self):
        """Placeholder for course management tab"""
        msg = ttk.Label(self.courses_tab, text="Course Management\n\nThis feature will be implemented in a future update.", font=("Arial", 14))
        msg.pack(expand=True, pady=100)
    
    def setup_enrollment_placeholder(self):
        """Placeholder for enrollment management tab"""
        msg = ttk.Label(self.enrollments_tab, text="Enrollment Management\n\nThis feature will be implemented in a future update.", font=("Arial", 14))
        msg.pack(expand=True, pady=100)
    
    def setup_reports_placeholder(self):
        """Placeholder for reports tab"""
        msg = ttk.Label(self.reports_tab, text="Reports\n\nThis feature will be implemented in a future update.", font=("Arial", 14))
        msg.pack(expand=True, pady=100)

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentManagementSystem(root)
    root.mainloop()