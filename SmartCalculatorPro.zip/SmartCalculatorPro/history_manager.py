class HistoryManager:
    def __init__(self, max_entries=100):
        self.history = []
        self.max_entries = max_entries
    
    def add_entry(self, entry):
        """
        Add a new entry to the calculation history
        
        Args:
            entry (str): The entry to add to history (usually in format "expression = result")
        """
        # Add the new entry to the beginning of the list
        self.history.append(entry)
        
        # Remove oldest entries if we exceed maximum capacity
        if len(self.history) > self.max_entries:
            self.history = self.history[-self.max_entries:]
    
    def get_entries(self):
        """
        Returns the list of history entries (most recent first)
        
        Returns:
            list: List of history entries
        """
        # Return a reversed copy of history to show newest entries first
        return self.history[::-1]
    
    def clear(self):
        """Clear all history entries"""
        self.history = []
    
    def get_entry(self, index):
        """
        Get a specific history entry by index
        
        Args:
            index (int): The index of the entry to retrieve
            
        Returns:
            str: The history entry or None if index is out of range
        """
        if 0 <= index < len(self.history):
            return self.history[index]
        return None
