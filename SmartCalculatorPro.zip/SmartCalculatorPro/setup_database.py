import sqlite3
import os

def setup_database():
    """
    Initialize the database using the SQL schema
    """
    # Check if database file exists and delete it if it does
    if os.path.exists('student_management.db'):
        os.remove('student_management.db')
        print("Removed existing database.")
    
    # Connect to the SQLite database (this will create it if it doesn't exist)
    conn = sqlite3.connect('student_management.db')
    cursor = conn.cursor()
    
    try:
        # Read the SQL schema file
        with open('student_db_schema.sql', 'r') as schema_file:
            schema_script = schema_file.read()
        
        # Execute the SQL script
        cursor.executescript(schema_script)
        
        # Commit the changes
        conn.commit()
        print("Database setup completed successfully!")
        
        # Show created tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        print("\nCreated tables:")
        for table in tables:
            print(f"- {table[0]}")
        
        # Show sample data from departments
        cursor.execute("SELECT id, name, code FROM departments;")
        departments = cursor.fetchall()
        print("\nSample departments:")
        for dept in departments:
            print(f"ID: {dept[0]}, Name: {dept[1]}, Code: {dept[2]}")
        
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        # Close the connection
        conn.close()

if __name__ == "__main__":
    setup_database()