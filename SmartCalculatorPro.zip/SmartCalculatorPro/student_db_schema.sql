-- Student Management System Database Schema
-- This file contains all SQL statements to create and initialize the database structure

-- Drop existing tables if they exist to ensure a clean setup
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS grades;

-- Create the departments table
CREATE TABLE departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    code TEXT NOT NULL UNIQUE,
    head_of_department TEXT,
    office_location TEXT,
    contact_email TEXT,
    contact_phone TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the students table
CREATE TABLE students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_number TEXT UNIQUE,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    zip_code TEXT,
    date_of_birth TEXT,
    gender TEXT,
    department_id INTEGER,
    enrollment_date TEXT,
    graduation_date TEXT,
    status TEXT DEFAULT 'Active', -- Active, Graduated, On Leave, Withdrawn
    gpa REAL DEFAULT 0.0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- Create the courses table
CREATE TABLE courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    description TEXT,
    department_id INTEGER,
    credit_hours INTEGER NOT NULL DEFAULT 3,
    prerequisites TEXT,
    level TEXT, -- Freshman, Sophomore, Junior, Senior, Graduate
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- Create the enrollments table to track student course enrollments
CREATE TABLE enrollments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    semester TEXT NOT NULL, -- e.g., "Fall 2025"
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'Enrolled', -- Enrolled, Completed, Withdrawn
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE(student_id, course_id, semester)
);

-- Create the grades table to track student performance
CREATE TABLE grades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    enrollment_id INTEGER NOT NULL,
    grade_value TEXT, -- A, B, C, D, F or numeric value
    grade_points REAL, -- 4.0, 3.0, etc.
    comments TEXT,
    graded_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE
);

-- Create indexes for performance optimization
CREATE INDEX idx_students_name ON students(last_name, first_name);
CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_students_department ON students(department_id);
CREATE INDEX idx_courses_department ON courses(department_id);
CREATE INDEX idx_enrollments_student ON enrollments(student_id);
CREATE INDEX idx_enrollments_course ON enrollments(course_id);
CREATE INDEX idx_grades_enrollment ON grades(enrollment_id);

-- Insert sample departments
INSERT INTO departments (name, code, head_of_department, office_location, contact_email, contact_phone) 
VALUES 
    ('Computer Science', 'CS', 'Dr. Alan Turing', 'Building A, Room 101', 'cs.dept@university.edu', '555-1234'),
    ('Electrical Engineering', 'EE', 'Dr. Nikola Tesla', 'Building B, Room 203', 'ee.dept@university.edu', '555-2345'),
    ('Mathematics', 'MATH', 'Dr. Ada Lovelace', 'Building C, Room 305', 'math.dept@university.edu', '555-3456'),
    ('Physics', 'PHYS', 'Dr. Albert Einstein', 'Building D, Room 407', 'physics.dept@university.edu', '555-4567'),
    ('Business Administration', 'BUS', 'Dr. Henry Ford', 'Building E, Room 509', 'business.dept@university.edu', '555-5678'),
    ('Psychology', 'PSYC', 'Dr. Sigmund Freud', 'Building F, Room 611', 'psych.dept@university.edu', '555-6789'),
    ('Mechanical Engineering', 'ME', 'Dr. Thomas Edison', 'Building G, Room 713', 'me.dept@university.edu', '555-7890'),
    ('Chemistry', 'CHEM', 'Dr. Marie Curie', 'Building H, Room 815', 'chem.dept@university.edu', '555-8901');

-- Create views for easier data access

-- View for student info with department name
CREATE VIEW view_student_details AS
SELECT 
    s.id,
    s.student_number,
    s.first_name,
    s.last_name,
    s.first_name || ' ' || s.last_name AS full_name,
    s.email,
    s.phone,
    s.address,
    s.city,
    s.state,
    s.zip_code,
    s.date_of_birth,
    s.gender,
    s.department_id,
    d.name AS department_name,
    d.code AS department_code,
    s.enrollment_date,
    s.graduation_date,
    s.status,
    s.gpa,
    s.notes,
    s.created_at,
    s.updated_at
FROM 
    students s
LEFT JOIN
    departments d ON s.department_id = d.id;

-- View for course info with department name
CREATE VIEW view_course_details AS
SELECT 
    c.id,
    c.course_code,
    c.title,
    c.description,
    c.department_id,
    d.name AS department_name,
    d.code AS department_code,
    c.credit_hours,
    c.prerequisites,
    c.level,
    c.created_at,
    c.updated_at
FROM 
    courses c
LEFT JOIN
    departments d ON c.department_id = d.id;

-- View for enrollment records with student and course info
CREATE VIEW view_enrollment_details AS
SELECT 
    e.id AS enrollment_id,
    e.student_id,
    s.first_name || ' ' || s.last_name AS student_name,
    s.student_number,
    e.course_id,
    c.course_code,
    c.title AS course_title,
    e.semester,
    e.enrollment_date,
    e.status AS enrollment_status,
    g.grade_value,
    g.grade_points,
    c.credit_hours,
    d.name AS department_name
FROM 
    enrollments e
JOIN
    students s ON e.student_id = s.id
JOIN
    courses c ON e.course_id = c.id
LEFT JOIN
    departments d ON c.department_id = d.id
LEFT JOIN
    grades g ON g.enrollment_id = e.id;

-- Create triggers to automatically update timestamps

-- Trigger to update students.updated_at
CREATE TRIGGER update_student_timestamp
AFTER UPDATE ON students
BEGIN
    UPDATE students SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Trigger to update departments.updated_at
CREATE TRIGGER update_department_timestamp
AFTER UPDATE ON departments
BEGIN
    UPDATE departments SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Trigger to update courses.updated_at
CREATE TRIGGER update_course_timestamp
AFTER UPDATE ON courses
BEGIN
    UPDATE courses SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Trigger to update grades.updated_at
CREATE TRIGGER update_grade_timestamp
AFTER UPDATE ON grades
BEGIN
    UPDATE grades SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Trigger to automatically update student GPA when grades are inserted/updated
CREATE TRIGGER update_student_gpa_after_grade_insert
AFTER INSERT ON grades
BEGIN
    UPDATE students
    SET gpa = (
        SELECT AVG(g.grade_points)
        FROM grades g
        JOIN enrollments e ON g.enrollment_id = e.id
        WHERE e.student_id = (
            SELECT e2.student_id 
            FROM enrollments e2 
            WHERE e2.id = NEW.enrollment_id
        )
    )
    WHERE id = (
        SELECT e3.student_id 
        FROM enrollments e3 
        WHERE e3.id = NEW.enrollment_id
    );
END;

CREATE TRIGGER update_student_gpa_after_grade_update
AFTER UPDATE ON grades
BEGIN
    UPDATE students
    SET gpa = (
        SELECT AVG(g.grade_points)
        FROM grades g
        JOIN enrollments e ON g.enrollment_id = e.id
        WHERE e.student_id = (
            SELECT e2.student_id 
            FROM enrollments e2 
            WHERE e2.id = NEW.enrollment_id
        )
    )
    WHERE id = (
        SELECT e3.student_id 
        FROM enrollments e3 
        WHERE e3.id = NEW.enrollment_id
    );
END;

-- Create function to generate student numbers
-- Not all SQLite implementations support CREATE FUNCTION, so this is provided as a reference
-- In actual code, this would be implemented in the application layer

-- Basic check constraints
-- Ensure GPA is between 0 and 4.0
CREATE TRIGGER check_student_gpa
BEFORE INSERT ON students
BEGIN
    SELECT
        CASE
            WHEN NEW.gpa < 0 OR NEW.gpa > 4.0 THEN
                RAISE(ABORT, 'GPA must be between 0.0 and 4.0')
        END;
END;

-- Ensure email format is valid (basic check)
CREATE TRIGGER check_student_email
BEFORE INSERT ON students
BEGIN
    SELECT
        CASE
            WHEN NEW.email NOT LIKE '%_@__%.__%' THEN
                RAISE(ABORT, 'Invalid email format')
        END;
END;

-- Ensure credit hours are positive
CREATE TRIGGER check_course_credit_hours
BEFORE INSERT ON courses
BEGIN
    SELECT
        CASE
            WHEN NEW.credit_hours <= 0 THEN
                RAISE(ABORT, 'Credit hours must be positive')
        END;
END;

-- Sample SELECT statements for common operations

-- Get all active students with their department information
-- SELECT * FROM view_student_details WHERE status = 'Active' ORDER BY last_name, first_name;

-- Get all courses for a specific department
-- SELECT * FROM view_course_details WHERE department_id = 1 ORDER BY course_code;

-- Get all enrollments for a specific student
-- SELECT * FROM view_enrollment_details WHERE student_id = 1 ORDER BY semester DESC;

-- Get all students enrolled in a specific course for a specific semester
-- SELECT * FROM view_enrollment_details WHERE course_id = 1 AND semester = 'Fall 2025' ORDER BY student_name;

-- Get GPA statistics by department
-- SELECT 
--     d.name AS department,
--     AVG(s.gpa) AS average_gpa,
--     MIN(s.gpa) AS minimum_gpa,
--     MAX(s.gpa) AS maximum_gpa,
--     COUNT(s.id) AS student_count
-- FROM students s
-- JOIN departments d ON s.department_id = d.id
-- WHERE s.status = 'Active'
-- GROUP BY d.id
-- ORDER BY average_gpa DESC;

-- Create an admin user for database access if needed
-- This would be used for an authentication system in a more complex app
-- CREATE TABLE IF NOT EXISTS users (
--     id INTEGER PRIMARY KEY AUTOINCREMENT,
--     username TEXT NOT NULL UNIQUE,
--     password_hash TEXT NOT NULL,
--     role TEXT NOT NULL DEFAULT 'user',
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );

-- INSERT INTO users (username, password_hash, role) 
-- VALUES ('admin', 'hashed_password_here', 'admin');

-- Instructions on how to use this schema:
-- 1. Create a new SQLite database: sqlite3 student_management.db
-- 2. Run this script: .read student_db_schema.sql
-- 3. Verify tables were created: .tables
-- 4. Check a sample table: SELECT * FROM departments;