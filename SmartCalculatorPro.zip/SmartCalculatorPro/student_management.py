import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import sqlite3
import os
import re
from datetime import datetime

class StudentManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Management System")
        self.root.geometry("1000x700")
        self.root.resizable(True, True)
        self.root.minsize(900, 600)
        
        # Database setup
        self.db_name = "students.db"
        self.create_database()
        
        # Set theme colors
        self.bg_color = "#f0f0f0"
        self.accent_color = "#3498db"
        self.text_color = "#333333"
        self.success_color = "#2ecc71"
        self.warning_color = "#e74c3c"
        
        # Set up the styles
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("TFrame", background=self.bg_color)
        self.style.configure("TLabel", background=self.bg_color, foreground=self.text_color)
        self.style.configure("TEntry", fieldbackground="white")
        self.style.configure("Accent.TButton", background=self.accent_color, foreground="white")
        self.style.map("Accent.TButton", background=[("active", "#2980b9")])
        
        # Variables for form inputs
        self.student_id_var = tk.StringVar()
        self.first_name_var = tk.StringVar()
        self.last_name_var = tk.StringVar()
        self.email_var = tk.StringVar()
        self.phone_var = tk.StringVar()
        self.dob_var = tk.StringVar()
        self.department_var = tk.StringVar()
        self.search_var = tk.StringVar()
        
        # Set up the UI components
        self.setup_main_frames()
        self.setup_form()
        self.setup_table()
        self.setup_search()
        
        # Populate the table
        self.display_all_students()
        
        # Set up validation
        self.setup_validation()
    
    def setup_main_frames(self):
        # Main container for the app
        self.main_frame = ttk.Frame(self.root, padding=20)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title label
        title_label = ttk.Label(self.main_frame, text="Student Management System", 
                              font=("Arial", 20, "bold"))
        title_label.pack(pady=(0, 20))
        
        # Split into left and right frames
        self.content_frame = ttk.Frame(self.main_frame)
        self.content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Left frame for form
        self.form_frame = ttk.LabelFrame(self.content_frame, text="Student Information", padding=15)
        self.form_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10), pady=5)
        
        # Right frame for the table
        self.table_frame = ttk.LabelFrame(self.content_frame, text="Student List", padding=15)
        self.table_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0), pady=5)
    
    def setup_form(self):
        # Create a frame for the form fields
        form_fields_frame = ttk.Frame(self.form_frame)
        form_fields_frame.pack(fill=tk.BOTH, expand=True)
        
        # Student ID
        ttk.Label(form_fields_frame, text="Student ID:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.student_id_var, width=30).grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        ttk.Label(form_fields_frame, text="(Auto-generated if empty)").grid(row=0, column=2, sticky="w", padx=5, pady=5)
        
        # First Name
        ttk.Label(form_fields_frame, text="First Name:*").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.first_name_var, width=30).grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        self.first_name_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.first_name_error.grid(row=1, column=2, sticky="w", padx=5, pady=5)
        
        # Last Name
        ttk.Label(form_fields_frame, text="Last Name:*").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.last_name_var, width=30).grid(row=2, column=1, sticky="ew", padx=5, pady=5)
        self.last_name_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.last_name_error.grid(row=2, column=2, sticky="w", padx=5, pady=5)
        
        # Email
        ttk.Label(form_fields_frame, text="Email:*").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.email_var, width=30).grid(row=3, column=1, sticky="ew", padx=5, pady=5)
        self.email_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.email_error.grid(row=3, column=2, sticky="w", padx=5, pady=5)
        
        # Phone
        ttk.Label(form_fields_frame, text="Phone:").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.phone_var, width=30).grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        self.phone_error = ttk.Label(form_fields_frame, text="", foreground=self.warning_color)
        self.phone_error.grid(row=4, column=2, sticky="w", padx=5, pady=5)
        
        # Date of Birth
        ttk.Label(form_fields_frame, text="Date of Birth:").grid(row=5, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form_fields_frame, textvariable=self.dob_var, width=30).grid(row=5, column=1, sticky="ew", padx=5, pady=5)
        ttk.Label(form_fields_frame, text="(YYYY-MM-DD)").grid(row=5, column=2, sticky="w", padx=5, pady=5)
        
        # Department
        ttk.Label(form_fields_frame, text="Department:*").grid(row=6, column=0, sticky="w", padx=5, pady=5)
        departments = ["Computer Science", "Electrical Engineering", "Mechanical Engineering", 
                      "Civil Engineering", "Business Administration", "Mathematics", "Physics", "Chemistry"]
        department_combo = ttk.Combobox(form_fields_frame, textvariable=self.department_var, values=departments, width=27)
        department_combo.grid(row=6, column=1, sticky="ew", padx=5, pady=5)
        
        # Additional notes
        ttk.Label(form_fields_frame, text="Notes:").grid(row=7, column=0, sticky="nw", padx=5, pady=5)
        self.notes_text = scrolledtext.ScrolledText(form_fields_frame, width=30, height=5)
        self.notes_text.grid(row=7, column=1, sticky="ew", padx=5, pady=5)
        
        # Required fields note
        required_note = ttk.Label(form_fields_frame, text="* Required fields", foreground=self.warning_color)
        required_note.grid(row=8, column=0, columnspan=3, sticky="w", padx=5, pady=5)
        
        # Create a frame for buttons
        button_frame = ttk.Frame(self.form_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Add buttons for CRUD operations
        ttk.Button(button_frame, text="Add Student", command=self.add_student, style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Update Selected", command=self.update_student).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete Selected", command=self.delete_student).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear Form", command=self.clear_form).pack(side=tk.LEFT, padx=5)
    
    def setup_table(self):
        # Create frame for search and buttons above table
        table_top_frame = ttk.Frame(self.table_frame)
        table_top_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Create the Treeview widget
        columns = ("id", "first_name", "last_name", "email", "phone", "dob", "department")
        self.tree = ttk.Treeview(self.table_frame, columns=columns, show="headings", selectmode="browse")
        
        # Define column headings
        self.tree.heading("id", text="ID")
        self.tree.heading("first_name", text="First Name")
        self.tree.heading("last_name", text="Last Name")
        self.tree.heading("email", text="Email")
        self.tree.heading("phone", text="Phone")
        self.tree.heading("dob", text="Date of Birth")
        self.tree.heading("department", text="Department")
        
        # Define column widths
        self.tree.column("id", width=50, anchor="center")
        self.tree.column("first_name", width=120, anchor="w")
        self.tree.column("last_name", width=120, anchor="w")
        self.tree.column("email", width=180, anchor="w")
        self.tree.column("phone", width=120, anchor="w")
        self.tree.column("dob", width=100, anchor="center")
        self.tree.column("department", width=150, anchor="w")
        
        # Bind the select event
        self.tree.bind("<<TreeviewSelect>>", self.load_selected_student)
        
        # Add a scrollbar
        scrollbar = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack the Treeview and scrollbar
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def setup_search(self):
        # Create search frame
        search_frame = ttk.Frame(self.main_frame)
        search_frame.pack(fill=tk.X, pady=(10, 0))
        
        # Search field
        ttk.Label(search_frame, text="Search Students:").pack(side=tk.LEFT, padx=(0, 5))
        ttk.Entry(search_frame, textvariable=self.search_var, width=40).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(search_frame, text="Search", command=self.search_students).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(search_frame, text="Clear Search", command=self.display_all_students).pack(side=tk.LEFT, padx=(0, 5))
    
    def setup_validation(self):
        # Set up validation for form fields
        
        # Track changes to form fields for real-time validation
        self.first_name_var.trace_add("write", lambda *args: self.validate_name(self.first_name_var, self.first_name_error, "First name"))
        self.last_name_var.trace_add("write", lambda *args: self.validate_name(self.last_name_var, self.last_name_error, "Last name"))
        self.email_var.trace_add("write", lambda *args: self.validate_email())
        self.phone_var.trace_add("write", lambda *args: self.validate_phone())
    
    def validate_name(self, var, error_label, field_name):
        name = var.get().strip()
        if name:
            if not name.replace(' ', '').isalpha():
                error_label.config(text=f"{field_name} should contain only letters")
                return False
            else:
                error_label.config(text="")
                return True
        else:
            error_label.config(text=f"{field_name} is required")
            return False
    
    def validate_email(self):
        email = self.email_var.get().strip()
        if email:
            # Simple email validation
            if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                self.email_error.config(text="Invalid email format")
                return False
            else:
                self.email_error.config(text="")
                return True
        else:
            self.email_error.config(text="Email is required")
            return False
    
    def validate_phone(self):
        phone = self.phone_var.get().strip()
        if phone:
            # Simple phone validation - digits, dashes, spaces, brackets, and plus sign
            if not re.match(r"^[\d\s\(\)\-\+]+$", phone):
                self.phone_error.config(text="Invalid phone format")
                return False
            else:
                self.phone_error.config(text="")
                return True
        else:
            # Phone is optional
            self.phone_error.config(text="")
            return True
    
    def validate_form(self):
        # Validate all form fields
        valid_first_name = self.validate_name(self.first_name_var, self.first_name_error, "First name")
        valid_last_name = self.validate_name(self.last_name_var, self.last_name_error, "Last name")
        valid_email = self.validate_email()
        valid_phone = self.validate_phone()
        
        # Check if department is selected
        if not self.department_var.get().strip():
            messagebox.showerror("Validation Error", "Department is required")
            return False
        
        # Check date of birth if provided
        dob = self.dob_var.get().strip()
        if dob:
            try:
                datetime.strptime(dob, '%Y-%m-%d')
            except ValueError:
                messagebox.showerror("Validation Error", "Date of birth must be in YYYY-MM-DD format")
                return False
        
        # Return overall validation result
        return valid_first_name and valid_last_name and valid_email and valid_phone
    
    def create_database(self):
        # Create database if it doesn't exist
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        # Create students table if it doesn't exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                phone TEXT,
                dob TEXT,
                department TEXT NOT NULL,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
        
        print(f"Database {self.db_name} initialized successfully")
    
    def add_student(self):
        # Validate form before adding
        if not self.validate_form():
            return
        
        # Get data from form
        student_id = self.student_id_var.get().strip()
        first_name = self.first_name_var.get().strip()
        last_name = self.last_name_var.get().strip()
        email = self.email_var.get().strip()
        phone = self.phone_var.get().strip()
        dob = self.dob_var.get().strip()
        department = self.department_var.get().strip()
        notes = self.notes_text.get("1.0", tk.END).strip()
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Check if trying to add with an existing ID
            if student_id:
                cursor.execute("SELECT id FROM students WHERE id = ?", (student_id,))
                if cursor.fetchone():
                    messagebox.showerror("Error", "A student with this ID already exists")
                    conn.close()
                    return
            
            # Check if email already exists
            cursor.execute("SELECT id FROM students WHERE email = ?", (email,))
            if cursor.fetchone():
                messagebox.showerror("Error", "A student with this email already exists")
                conn.close()
                return
            
            # Insert new student
            if student_id:  # If ID is provided, use it
                cursor.execute('''
                    INSERT INTO students (id, first_name, last_name, email, phone, dob, department, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (student_id, first_name, last_name, email, phone, dob, department, notes))
            else:  # Otherwise let SQLite generate an ID
                cursor.execute('''
                    INSERT INTO students (first_name, last_name, email, phone, dob, department, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (first_name, last_name, email, phone, dob, department, notes))
            
            conn.commit()
            messagebox.showinfo("Success", f"Student {first_name} {last_name} added successfully")
            
            # Refresh the table and clear the form
            self.clear_form()
            self.display_all_students()
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def update_student(self):
        # Check if a student is selected
        selected_items = self.tree.selection()
        if not selected_items:
            messagebox.showinfo("Info", "Please select a student to update")
            return
        
        # Validate form before updating
        if not self.validate_form():
            return
        
        # Get data from form
        student_id = self.student_id_var.get().strip()
        first_name = self.first_name_var.get().strip()
        last_name = self.last_name_var.get().strip()
        email = self.email_var.get().strip()
        phone = self.phone_var.get().strip()
        dob = self.dob_var.get().strip()
        department = self.department_var.get().strip()
        notes = self.notes_text.get("1.0", tk.END).strip()
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Check if email already exists for other students
            cursor.execute("SELECT id FROM students WHERE email = ? AND id != ?", (email, student_id))
            if cursor.fetchone():
                messagebox.showerror("Error", "Another student with this email already exists")
                conn.close()
                return
            
            # Update student
            cursor.execute('''
                UPDATE students
                SET first_name = ?, last_name = ?, email = ?, phone = ?, dob = ?, department = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (first_name, last_name, email, phone, dob, department, notes, student_id))
            
            conn.commit()
            messagebox.showinfo("Success", f"Student {first_name} {last_name} updated successfully")
            
            # Refresh the table and clear the form
            self.clear_form()
            self.display_all_students()
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def delete_student(self):
        # Check if a student is selected
        selected_items = self.tree.selection()
        if not selected_items:
            messagebox.showinfo("Info", "Please select a student to delete")
            return
        
        # Get student ID
        student_id = self.tree.item(selected_items[0], "values")[0]
        
        # Confirm deletion
        if not messagebox.askyesno("Confirm", "Are you sure you want to delete this student?"):
            return
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Delete student
            cursor.execute("DELETE FROM students WHERE id = ?", (student_id,))
            
            conn.commit()
            messagebox.showinfo("Success", "Student deleted successfully")
            
            # Refresh the table and clear the form
            self.clear_form()
            self.display_all_students()
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def load_selected_student(self, event):
        # Get selected student data
        selected_items = self.tree.selection()
        if not selected_items:
            return
        
        # Get values from the selected row
        values = self.tree.item(selected_items[0], "values")
        student_id = values[0]
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Get full student data including notes
            cursor.execute('''
                SELECT id, first_name, last_name, email, phone, dob, department, notes
                FROM students 
                WHERE id = ?
            ''', (student_id,))
            
            student = cursor.fetchone()
            if student:
                # Clear errors
                self.first_name_error.config(text="")
                self.last_name_error.config(text="")
                self.email_error.config(text="")
                self.phone_error.config(text="")
                
                # Populate form fields
                self.student_id_var.set(student[0])
                self.first_name_var.set(student[1])
                self.last_name_var.set(student[2])
                self.email_var.set(student[3])
                self.phone_var.set(student[4] if student[4] else "")
                self.dob_var.set(student[5] if student[5] else "")
                self.department_var.set(student[6])
                
                # Set notes
                self.notes_text.delete("1.0", tk.END)
                if student[7]:
                    self.notes_text.insert("1.0", student[7])
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def clear_form(self):
        # Clear all form fields
        self.student_id_var.set("")
        self.first_name_var.set("")
        self.last_name_var.set("")
        self.email_var.set("")
        self.phone_var.set("")
        self.dob_var.set("")
        self.department_var.set("")
        self.notes_text.delete("1.0", tk.END)
        
        # Clear error messages
        self.first_name_error.config(text="")
        self.last_name_error.config(text="")
        self.email_error.config(text="")
        self.phone_error.config(text="")
        
        # Deselect tree item
        for selected_item in self.tree.selection():
            self.tree.selection_remove(selected_item)
    
    def display_all_students(self):
        # Clear search field
        self.search_var.set("")
        
        # Clear the treeview
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Get all students
            cursor.execute('''
                SELECT id, first_name, last_name, email, phone, dob, department
                FROM students
                ORDER BY last_name, first_name
            ''')
            
            # Add students to treeview
            for student in cursor.fetchall():
                self.tree.insert("", tk.END, values=student)
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()
    
    def search_students(self):
        # Get search text
        search_text = self.search_var.get().strip().lower()
        if not search_text:
            self.display_all_students()
            return
        
        # Clear the treeview
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            # Search in multiple fields
            cursor.execute('''
                SELECT id, first_name, last_name, email, phone, dob, department
                FROM students
                WHERE lower(first_name) LIKE ? OR lower(last_name) LIKE ? OR lower(email) LIKE ? OR lower(department) LIKE ?
                ORDER BY last_name, first_name
            ''', (f"%{search_text}%", f"%{search_text}%", f"%{search_text}%", f"%{search_text}%"))
            
            # Add matching students to treeview
            students = cursor.fetchall()
            for student in students:
                self.tree.insert("", tk.END, values=student)
            
            # Show search results count
            if not students:
                messagebox.showinfo("Search Results", "No students match your search criteria")
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")
        finally:
            conn.close()

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentManagementSystem(root)
    root.mainloop()