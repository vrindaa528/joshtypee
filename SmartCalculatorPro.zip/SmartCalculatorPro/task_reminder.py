import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import datetime
import time
import threading
import json
import os
import random
import sys

class TaskReminder:
    def __init__(self, root):
        self.root = root
        self.root.title("Task Reminder with Alarm")
        self.root.geometry("900x600")
        self.root.resizable(True, True)
        self.root.minsize(900, 600)
        
        # Set theme colors
        self.bg_color = "#f5f5f5"
        self.accent_color = "#4CAF50"
        self.text_color = "#333333"
        self.warning_color = "#f44336"
        
        # Configure root window
        self.root.configure(bg=self.bg_color)
        
        # Initialize tasks list
        self.tasks = []
        self.alarm_threads = []
        self.notification_sound = "notification.wav"
        
        # Check if notification sound exists, otherwise create a dummy one
        if not os.path.exists(self.notification_sound):
            self.create_dummy_sound(self.notification_sound)
        
        # Load existing tasks
        self.load_tasks()
        
        # Create main frames
        self.create_frames()
        
        # Create components
        self.create_task_form()
        self.create_task_list()
        
        # Start monitoring thread
        self.stop_thread = False
        self.monitor_thread = threading.Thread(target=self.monitor_tasks)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
    def create_dummy_sound(self, filename):
        try:
            # Create a simple text file with instructions on how to replace it
            with open(filename, 'w') as f:
                f.write("This is a placeholder for the notification sound. Replace this file with a valid .wav sound file.")
            print(f"Created placeholder file for {filename}")
        except Exception as e:
            print(f"Error creating placeholder sound file: {e}")
    
    def create_frames(self):
        # Create main frame
        self.main_frame = ttk.Frame(self.root, padding=20)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create frames for form and list
        self.form_frame = ttk.LabelFrame(self.main_frame, text="Add New Task", padding=15)
        self.form_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.list_frame = ttk.LabelFrame(self.main_frame, text="Your Tasks", padding=15)
        self.list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
    
    def create_task_form(self):
        # Task title
        ttk.Label(self.form_frame, text="Task Title:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.title_var = tk.StringVar()
        ttk.Entry(self.form_frame, textvariable=self.title_var, width=40).grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        
        # Task description
        ttk.Label(self.form_frame, text="Description:").grid(row=1, column=0, sticky="nw", padx=5, pady=5)
        self.description_text = scrolledtext.ScrolledText(self.form_frame, width=40, height=3)
        self.description_text.grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        
        # Due date and time
        ttk.Label(self.form_frame, text="Due Date:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        
        date_frame = ttk.Frame(self.form_frame)
        date_frame.grid(row=2, column=1, sticky="ew", padx=5, pady=5)
        
        # Date picker
        today = datetime.datetime.now()
        
        # Year
        self.year_var = tk.StringVar(value=str(today.year))
        ttk.Label(date_frame, text="Year:").pack(side=tk.LEFT, padx=(0, 5))
        year_spin = ttk.Spinbox(date_frame, from_=today.year, to=today.year+10, textvariable=self.year_var, width=6)
        year_spin.pack(side=tk.LEFT, padx=(0, 10))
        
        # Month
        self.month_var = tk.StringVar(value=str(today.month))
        ttk.Label(date_frame, text="Month:").pack(side=tk.LEFT, padx=(0, 5))
        month_spin = ttk.Spinbox(date_frame, from_=1, to=12, textvariable=self.month_var, width=3)
        month_spin.pack(side=tk.LEFT, padx=(0, 10))
        
        # Day
        self.day_var = tk.StringVar(value=str(today.day))
        ttk.Label(date_frame, text="Day:").pack(side=tk.LEFT, padx=(0, 5))
        day_spin = ttk.Spinbox(date_frame, from_=1, to=31, textvariable=self.day_var, width=3)
        day_spin.pack(side=tk.LEFT, padx=(0, 10))
        
        # Time picker
        ttk.Label(self.form_frame, text="Due Time:").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        
        time_frame = ttk.Frame(self.form_frame)
        time_frame.grid(row=3, column=1, sticky="ew", padx=5, pady=5)
        
        # Hour
        self.hour_var = tk.StringVar(value=str(today.hour))
        ttk.Label(time_frame, text="Hour:").pack(side=tk.LEFT, padx=(0, 5))
        hour_spin = ttk.Spinbox(time_frame, from_=0, to=23, textvariable=self.hour_var, width=3)
        hour_spin.pack(side=tk.LEFT, padx=(0, 10))
        
        # Minute
        self.minute_var = tk.StringVar(value=str(today.minute))
        ttk.Label(time_frame, text="Min:").pack(side=tk.LEFT, padx=(0, 5))
        minute_spin = ttk.Spinbox(time_frame, from_=0, to=59, textvariable=self.minute_var, width=3)
        minute_spin.pack(side=tk.LEFT, padx=(0, 10))
        
        # Priority
        ttk.Label(self.form_frame, text="Priority:").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        
        priority_frame = ttk.Frame(self.form_frame)
        priority_frame.grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        
        self.priority_var = tk.StringVar(value="Medium")
        ttk.Radiobutton(priority_frame, text="Low", variable=self.priority_var, value="Low").pack(side=tk.LEFT, padx=(0, 10))
        ttk.Radiobutton(priority_frame, text="Medium", variable=self.priority_var, value="Medium").pack(side=tk.LEFT, padx=(0, 10))
        ttk.Radiobutton(priority_frame, text="High", variable=self.priority_var, value="High").pack(side=tk.LEFT, padx=(0, 10))
        
        # Reminder options
        ttk.Label(self.form_frame, text="Reminder:").grid(row=5, column=0, sticky="w", padx=5, pady=5)
        
        reminder_frame = ttk.Frame(self.form_frame)
        reminder_frame.grid(row=5, column=1, sticky="ew", padx=5, pady=5)
        
        self.reminder_var = tk.IntVar(value=15)
        ttk.Label(reminder_frame, text="Remind me").pack(side=tk.LEFT, padx=(0, 5))
        reminder_spin = ttk.Spinbox(reminder_frame, from_=1, to=60, textvariable=self.reminder_var, width=3)
        reminder_spin.pack(side=tk.LEFT, padx=(0, 5))
        ttk.Label(reminder_frame, text="minutes before").pack(side=tk.LEFT, padx=(0, 5))
        
        # Add button
        buttons_frame = ttk.Frame(self.form_frame)
        buttons_frame.grid(row=6, column=0, columnspan=2, sticky="e", padx=5, pady=10)
        
        ttk.Button(buttons_frame, text="Add Task", command=self.add_task).pack(side=tk.RIGHT, padx=5)
        ttk.Button(buttons_frame, text="Clear Form", command=self.clear_form).pack(side=tk.RIGHT, padx=5)
    
    def create_task_list(self):
        # Create treeview for task list
        columns = ("id", "title", "priority", "due_date", "status")
        self.tree = ttk.Treeview(self.list_frame, columns=columns, show="headings", selectmode="browse")
        
        # Define columns
        self.tree.heading("id", text="ID")
        self.tree.heading("title", text="Task")
        self.tree.heading("priority", text="Priority")
        self.tree.heading("due_date", text="Due Date & Time")
        self.tree.heading("status", text="Status")
        
        # Set column widths
        self.tree.column("id", width=50, anchor="center")
        self.tree.column("title", width=200, anchor="w")
        self.tree.column("priority", width=80, anchor="center")
        self.tree.column("due_date", width=150, anchor="center")
        self.tree.column("status", width=100, anchor="center")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self.list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack treeview and scrollbar
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Add action buttons
        button_frame = ttk.Frame(self.main_frame)
        button_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(button_frame, text="View Details", command=self.view_task).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Complete Task", command=self.complete_task).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete Task", command=self.delete_task).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete All Completed", command=self.delete_completed).pack(side=tk.LEFT, padx=5)
        
        # Refresh task list
        self.refresh_task_list()
    
    def add_task(self):
        # Get task details from form
        title = self.title_var.get().strip()
        description = self.description_text.get("1.0", tk.END).strip()
        
        # Validate input
        if not title:
            messagebox.showerror("Error", "Task title is required!")
            return
        
        try:
            # Get date and time components
            year = int(self.year_var.get())
            month = int(self.month_var.get())
            day = int(self.day_var.get())
            hour = int(self.hour_var.get())
            minute = int(self.minute_var.get())
            
            # Create datetime object
            due_date = datetime.datetime(year, month, day, hour, minute)
            
            # Check if due date is in the past
            if due_date < datetime.datetime.now():
                messagebox.showerror("Error", "Due date cannot be in the past!")
                return
                
        except ValueError:
            messagebox.showerror("Error", "Invalid date or time values!")
            return
        
        # Get priority and reminder time
        priority = self.priority_var.get()
        reminder_minutes = int(self.reminder_var.get())
        
        # Generate unique ID for task
        task_id = self.generate_id()
        
        # Create task object
        task = {
            "id": task_id,
            "title": title,
            "description": description,
            "due_date": due_date.strftime("%Y-%m-%d %H:%M"),
            "priority": priority,
            "reminder_minutes": reminder_minutes,
            "status": "Pending",
            "completed_date": None
        }
        
        # Add task to list
        self.tasks.append(task)
        
        # Save tasks to file
        self.save_tasks()
        
        # Refresh task list
        self.refresh_task_list()
        
        # Clear form
        self.clear_form()
        
        # Show confirmation
        messagebox.showinfo("Success", f"Task '{title}' added successfully!")
    
    def clear_form(self):
        self.title_var.set("")
        self.description_text.delete("1.0", tk.END)
        
        # Reset date and time to current
        now = datetime.datetime.now()
        self.year_var.set(str(now.year))
        self.month_var.set(str(now.month))
        self.day_var.set(str(now.day))
        self.hour_var.set(str(now.hour))
        self.minute_var.set(str(now.minute))
        
        # Reset priority and reminder
        self.priority_var.set("Medium")
        self.reminder_var.set(15)
    
    def generate_id(self):
        # Generate a unique ID for the task
        if not self.tasks:
            return 1
            
        # Find the maximum ID and increment by 1
        max_id = max(task["id"] for task in self.tasks)
        return max_id + 1
    
    def refresh_task_list(self):
        # Clear the treeview
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        # Sort tasks by due date and priority
        sorted_tasks = sorted(self.tasks, key=lambda x: (x["status"] == "Completed",
                                                      datetime.datetime.strptime(x["due_date"], "%Y-%m-%d %H:%M"),
                                                      {"High": 0, "Medium": 1, "Low": 2}[x["priority"]]))
        
        # Add tasks to treeview
        for task in sorted_tasks:
            # Format due date
            due_date = datetime.datetime.strptime(task["due_date"], "%Y-%m-%d %H:%M")
            formatted_date = due_date.strftime("%b %d, %Y %H:%M")
            
            # Set row tags based on status and priority
            tags = []
            if task["status"] == "Completed":
                tags.append("completed")
            elif due_date < datetime.datetime.now():
                tags.append("overdue")
            elif task["priority"] == "High":
                tags.append("high_priority")
            
            # Insert row
            self.tree.insert("", tk.END, values=(
                task["id"],
                task["title"],
                task["priority"],
                formatted_date,
                task["status"]
            ), tags=tags)
        
        # Configure row colors
        self.tree.tag_configure("completed", foreground="gray")
        self.tree.tag_configure("overdue", foreground="red")
        self.tree.tag_configure("high_priority", foreground="orangered")
    
    def view_task(self):
        # Get selected task
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Please select a task to view")
            return
            
        # Get task ID from selected item
        task_id = int(self.tree.item(selected_item, "values")[0])
        
        # Find task by ID
        task = next((t for t in self.tasks if t["id"] == task_id), None)
        if not task:
            messagebox.showerror("Error", "Task not found")
            return
            
        # Create a new window to display task details
        detail_window = tk.Toplevel(self.root)
        detail_window.title(f"Task Details: {task['title']}")
        detail_window.geometry("500x400")
        detail_window.resizable(True, True)
        detail_window.minsize(500, 400)
        detail_window.transient(self.root)
        detail_window.focus_set()
        
        # Create a frame for task details
        detail_frame = ttk.Frame(detail_window, padding=20)
        detail_frame.pack(fill=tk.BOTH, expand=True)
        
        # Display task details
        ttk.Label(detail_frame, text=task["title"], font=("Arial", 16, "bold")).pack(anchor="w", pady=(0, 10))
        
        # Status and priority
        status_frame = ttk.Frame(detail_frame)
        status_frame.pack(fill=tk.X, pady=(0, 10))
        
        status_color = "gray" if task["status"] == "Completed" else (
            "red" if datetime.datetime.strptime(task["due_date"], "%Y-%m-%d %H:%M") < datetime.datetime.now() else "green"
        )
        
        ttk.Label(status_frame, text=f"Status: ", font=("Arial", 10)).pack(side=tk.LEFT)
        ttk.Label(status_frame, text=task["status"], foreground=status_color, font=("Arial", 10, "bold")).pack(side=tk.LEFT)
        
        ttk.Label(status_frame, text=f"   Priority: ", font=("Arial", 10)).pack(side=tk.LEFT)
        priority_color = {"High": "red", "Medium": "orange", "Low": "green"}[task["priority"]]
        ttk.Label(status_frame, text=task["priority"], foreground=priority_color, font=("Arial", 10, "bold")).pack(side=tk.LEFT)
        
        # Due date
        due_date = datetime.datetime.strptime(task["due_date"], "%Y-%m-%d %H:%M")
        formatted_date = due_date.strftime("%A, %B %d, %Y at %H:%M")
        ttk.Label(detail_frame, text=f"Due: {formatted_date}", font=("Arial", 10)).pack(anchor="w", pady=(0, 5))
        
        # Reminder setting
        ttk.Label(detail_frame, text=f"Reminder: {task['reminder_minutes']} minutes before due time", font=("Arial", 10)).pack(anchor="w", pady=(0, 10))
        
        # Description heading
        ttk.Label(detail_frame, text="Description:", font=("Arial", 12, "bold")).pack(anchor="w", pady=(10, 5))
        
        # Description text
        desc_text = scrolledtext.ScrolledText(detail_frame, wrap=tk.WORD, height=10)
        desc_text.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        desc_text.insert(tk.END, task["description"] if task["description"] else "No description provided.")
        desc_text.configure(state="disabled")
        
        # If task is completed, show completion date
        if task["status"] == "Completed" and task["completed_date"]:
            completed_date = datetime.datetime.strptime(task["completed_date"], "%Y-%m-%d %H:%M")
            formatted_completed = completed_date.strftime("%A, %B %d, %Y at %H:%M")
            ttk.Label(detail_frame, text=f"Completed on: {formatted_completed}", font=("Arial", 10, "italic")).pack(anchor="w", pady=(10, 0))
        
        # Button to close window
        ttk.Button(detail_frame, text="Close", command=detail_window.destroy).pack(anchor="e", pady=(10, 0))
    
    def complete_task(self):
        # Get selected task
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Please select a task to mark as completed")
            return
            
        # Get task ID from selected item
        task_id = int(self.tree.item(selected_item, "values")[0])
        
        # Find task by ID
        task = next((t for t in self.tasks if t["id"] == task_id), None)
        if not task:
            messagebox.showerror("Error", "Task not found")
            return
            
        # If already completed, ask if user wants to mark as pending
        if task["status"] == "Completed":
            result = messagebox.askyesno("Confirm", "This task is already completed. Do you want to mark it as pending?")
            if result:
                task["status"] = "Pending"
                task["completed_date"] = None
                messagebox.showinfo("Success", f"Task '{task['title']}' marked as pending")
        else:
            # Mark task as completed
            task["status"] = "Completed"
            task["completed_date"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            messagebox.showinfo("Success", f"Task '{task['title']}' marked as completed")
        
        # Save changes
        self.save_tasks()
        
        # Refresh task list
        self.refresh_task_list()
    
    def delete_task(self):
        # Get selected task
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Please select a task to delete")
            return
            
        # Get task ID from selected item
        task_id = int(self.tree.item(selected_item, "values")[0])
        
        # Find task by ID
        task = next((t for t in self.tasks if t["id"] == task_id), None)
        if not task:
            messagebox.showerror("Error", "Task not found")
            return
            
        # Confirm deletion
        result = messagebox.askyesno("Confirm", f"Are you sure you want to delete the task '{task['title']}'?")
        if not result:
            return
            
        # Remove task from list
        self.tasks = [t for t in self.tasks if t["id"] != task_id]
        
        # Save changes
        self.save_tasks()
        
        # Refresh task list
        self.refresh_task_list()
        
        # Show confirmation
        messagebox.showinfo("Success", f"Task '{task['title']}' deleted successfully")
    
    def delete_completed(self):
        # Check if there are any completed tasks
        completed_tasks = [t for t in self.tasks if t["status"] == "Completed"]
        if not completed_tasks:
            messagebox.showinfo("Info", "There are no completed tasks to delete")
            return
            
        # Confirm deletion
        result = messagebox.askyesno("Confirm", f"Are you sure you want to delete all {len(completed_tasks)} completed tasks?")
        if not result:
            return
            
        # Remove completed tasks
        self.tasks = [t for t in self.tasks if t["status"] != "Completed"]
        
        # Save changes
        self.save_tasks()
        
        # Refresh task list
        self.refresh_task_list()
        
        # Show confirmation
        messagebox.showinfo("Success", f"{len(completed_tasks)} completed tasks deleted successfully")
    
    def save_tasks(self):
        # Convert datetime objects to strings for JSON serialization
        tasks_to_save = self.tasks.copy()
        
        # Save tasks to file
        try:
            with open("tasks.json", "w") as file:
                json.dump(tasks_to_save, file, indent=4)
            print("Tasks saved successfully")
        except Exception as e:
            print(f"Error saving tasks: {e}")
            messagebox.showerror("Error", f"Failed to save tasks: {e}")
    
    def load_tasks(self):
        # Check if tasks file exists
        if not os.path.exists("tasks.json"):
            self.tasks = []
            return
            
        # Load tasks from file
        try:
            with open("tasks.json", "r") as file:
                self.tasks = json.load(file)
            print(f"Loaded {len(self.tasks)} tasks from file")
        except Exception as e:
            print(f"Error loading tasks: {e}")
            messagebox.showerror("Error", f"Failed to load tasks: {e}")
            self.tasks = []
    
    def monitor_tasks(self):
        while not self.stop_thread:
            now = datetime.datetime.now()
            
            # Check each pending task for reminders
            for task in self.tasks:
                if task["status"] == "Pending":
                    due_datetime = datetime.datetime.strptime(task["due_date"], "%Y-%m-%d %H:%M")
                    reminder_time = due_datetime - datetime.timedelta(minutes=task["reminder_minutes"])
                    
                    # Check if it's time for the reminder (within the last minute)
                    time_diff = (now - reminder_time).total_seconds()
                    if 0 <= time_diff <= 60:
                        self.show_reminder(task)
                    
                    # Also check if the task is now overdue (within the last minute)
                    time_diff = (now - due_datetime).total_seconds()
                    if 0 <= time_diff <= 60:
                        self.show_overdue(task)
            
            # Sleep for 30 seconds before checking again
            time.sleep(30)
    
    def show_reminder(self, task):
        # Create reminder notification
        remind_title = f"Reminder: {task['title']}"
        due_datetime = datetime.datetime.strptime(task["due_date"], "%Y-%m-%d %H:%M")
        remind_message = f"Task is due in {task['reminder_minutes']} minutes at {due_datetime.strftime('%H:%M')}"
        
        # Play sound in a separate thread to avoid blocking
        threading.Thread(target=self.play_notification_sound).start()
        
        # Show message box
        self.root.after(0, lambda: messagebox.showinfo(remind_title, remind_message))
    
    def show_overdue(self, task):
        # Create overdue notification
        overdue_title = f"Task Overdue: {task['title']}"
        overdue_message = f"This task is now overdue! Please complete it as soon as possible."
        
        # Play sound in a separate thread to avoid blocking
        threading.Thread(target=self.play_notification_sound).start()
        
        # Show message box
        self.root.after(0, lambda: messagebox.showwarning(overdue_title, overdue_message))
    
    def play_notification_sound(self):
        try:
            # Use system beep instead of playsound
            print("Playing notification sound")
            for _ in range(3):
                self.root.bell()
                time.sleep(0.3)
        except Exception as e:
            print(f"Error playing notification sound: {e}")
    
    def on_closing(self):
        # Set the stop flag for monitoring thread
        self.stop_thread = True
        
        # Wait for thread to finish (with timeout)
        if self.monitor_thread.is_alive():
            self.monitor_thread.join(1)
        
        # Save tasks before closing
        self.save_tasks()
        
        # Destroy the window
        self.root.destroy()

if __name__ == "__main__":
    try:
        # Check if running in frozen/packaged mode
        if getattr(sys, 'frozen', False):
            # If frozen, use the directory of the executable
            application_path = os.path.dirname(sys.executable)
        else:
            # If not frozen, use the directory of this script
            application_path = os.path.dirname(os.path.abspath(__file__))
            
        # Change to application directory
        os.chdir(application_path)
        
        # Create and run the application
        root = tk.Tk()
        style = ttk.Style()
        style.theme_use('clam')  # Use the 'clam' theme which looks better across platforms
        app = TaskReminder(root)
        root.protocol("WM_DELETE_WINDOW", app.on_closing)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")
        raise