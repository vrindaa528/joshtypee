import tkinter as tk

class ThemeManager:
    def __init__(self, root):
        self.root = root
        self.dark_mode = False
        
        # Define themes
        self.light_theme = {
            "bg": "#f0f0f0",
            "fg": "#000000",
            "entry_bg": "#ffffff",
            "entry_fg": "#000000",
            "button_bg": "#e0e0e0",
            "button_fg": "#000000",
            "highlight_bg": "#d9d9d9",
            "display_bg": "#ffffff",
            "listbox_bg": "#ffffff",
            "listbox_fg": "#000000",
        }
        
        self.dark_theme = {
            "bg": "#333333",
            "fg": "#ffffff",
            "entry_bg": "#444444",
            "entry_fg": "#ffffff",
            "button_bg": "#555555",
            "button_fg": "#ffffff",
            "highlight_bg": "#666666",
            "display_bg": "#222222",
            "listbox_bg": "#444444",
            "listbox_fg": "#ffffff",
        }
        
        # Set default style as light theme
        self.current_theme = self.light_theme

    def toggle_theme(self):
        """Toggle between light and dark theme"""
        self.dark_mode = not self.dark_mode
        self.current_theme = self.dark_theme if self.dark_mode else self.light_theme
        self.apply_theme()
    
    def is_dark_mode(self):
        """Return current theme status"""
        return self.dark_mode
    
    def apply_theme(self):
        """Apply the current theme to all widgets"""
        # Configure root window theme
        self.root.configure(bg=self.current_theme["bg"])
        
        # Apply theme to all frames and their children
        self._apply_theme_to_widget(self.root)
    
    def _apply_theme_to_widget(self, widget):
        """Recursively apply theme to a widget and all its children"""
        # Skip certain widget types that have custom styling
        if widget.winfo_children():
            for child in widget.winfo_children():
                self._apply_theme_to_widget(child)
        
        try:
            widget_type = widget.winfo_class()
            
            # Apply theme based on widget type
            if widget_type in ('Frame', 'Toplevel', 'Tk'):
                widget.configure(bg=self.current_theme["bg"])
                
            elif widget_type == 'Label':
                widget.configure(
                    bg=self.current_theme["bg"],
                    fg=self.current_theme["fg"]
                )
                
            elif widget_type == 'Button':
                # Skip buttons with special colors (they will be handled separately)
                if widget['text'] not in ('=', 'AC', 'DEL', '+', '-', '×', '÷'):
                    widget.configure(
                        bg=self.current_theme["button_bg"],
                        fg=self.current_theme["button_fg"],
                        activebackground=self.current_theme["highlight_bg"],
                        activeforeground=self.current_theme["fg"]
                    )
                
            elif widget_type == 'Entry':
                widget.configure(
                    bg=self.current_theme["entry_bg"],
                    fg=self.current_theme["entry_fg"],
                    insertbackground=self.current_theme["fg"]  # cursor color
                )
                
            elif widget_type == 'Listbox':
                widget.configure(
                    bg=self.current_theme["listbox_bg"],
                    fg=self.current_theme["listbox_fg"],
                    selectbackground=self.current_theme["highlight_bg"],
                    selectforeground=self.current_theme["fg"]
                )
                
        except tk.TclError:
            # Some widgets might not support all configurations
            pass
